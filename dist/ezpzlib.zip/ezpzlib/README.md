# Ezpizee's PHP Libraries

https://github.com/ezpizee/php-libs

```
composer install
```

OR

```
php composer.phar install
```