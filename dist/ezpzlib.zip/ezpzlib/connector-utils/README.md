Ezpizee PHP Connector Utils
============================

PHP utility classes for Ezpizee's PHP connectors
https://github.com/ezpizee/PHPConnectorUtils

## Installation

```
composer require ezpizee/connector-utils "dev-master"
```
