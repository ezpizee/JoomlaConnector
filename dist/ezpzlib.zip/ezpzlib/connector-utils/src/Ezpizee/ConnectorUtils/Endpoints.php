<?php

namespace Ezpizee\ConnectorUtils;

class Endpoints
{
  const INSTALL = '/api/install';
  const GET_TOKEN = '/api/user/token';
}
