Ezpizee PHP Context Processor
============================

For all Ezpizee utility classes
https://github.com/ezpizee/PHPBaseContextProcessor

## Installation

```
composer require ezpizee/contextprocessor "dev-master"
```
