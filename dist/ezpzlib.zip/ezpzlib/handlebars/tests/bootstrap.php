<?php
include __DIR__ . "/../src/Handlebars/Autoloader.php";
