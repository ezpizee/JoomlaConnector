Ezpizee Microservices Client
============================

For connecting to our microservices (likely using Kong's unirest)
https://github.com/ezpizee/microservices-client

## Installation

```
composer require ezpizee/microservices-client "dev-master"
```
