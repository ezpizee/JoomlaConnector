Ezpizee Utils
============================

For all Ezpizee utility classes
https://github.com/ezpizee/microservices-utils

## Installation

```
composer require ezpizee/utils "dev-master"
```
