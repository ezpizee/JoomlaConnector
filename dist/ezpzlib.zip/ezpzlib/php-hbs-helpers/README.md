# PHP Handlebars Helpers

``
composer require webconsol/php-hbs-helpers "dev-master"
``

OR, depending on your composer setup

``
php composer.phar require webconsol/php-hbs-helpers "dev-master"
``
